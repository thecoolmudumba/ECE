The ESP32 and breadboard schematics are the same as Lab 1. No new modifications have been made for Lab 2. Please refer to Lab 1 schematics on my github page to access this information:

https://github.com/smudumba2019/ECE/blob/main/ECE%2056800%20Embedded%20Systems/Laboratory%20(ESP32%20Microcontroller)/readme.md


To access the short video of the demonstrating working solution, please visit the YouTube link below:

https://youtu.be/WvnHGL8EV0M



